﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Employee.DAL;
using System.Data.SqlClient;

namespace Employee.BLL
{
    public class clsLocation
    {
        public clsLocation()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        #region Variables
        DBBridge objDBBridge = new DBBridge();
        protected int _LocationfrmId;
        protected string _LocationfrmName = String.Empty;
        const string _spName = "sp_tblLocation";
        #endregion

        #region Class Property
        public int LocationfrmId
        {
            get { return _LocationfrmId; }
            set { _LocationfrmId = value; }
        }

        public string LocationfrmName
        {
            get { return _LocationfrmName; }
            set { _LocationfrmName = value; }
        }

        #endregion

        #region Public Methods

        public int Insert()
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@Mode", "Insert");
            param[1] = new SqlParameter("@LocationfrmName", _LocationfrmName);
            return objDBBridge.ExecuteNonQuery(_spName, param);
        }

        public int Update()
        {
            SqlParameter[] param = new SqlParameter[3];
            param[0] = new SqlParameter("@Mode", "Update");
            param[1] = new SqlParameter("@LocationfrmName", _LocationfrmName);
            param[2] = new SqlParameter("@LocationfrmId", _LocationfrmId);
            return objDBBridge.ExecuteNonQuery(_spName, param);
        }

        public int Delete()
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@Mode", "Delete");
            param[1] = new SqlParameter("@LocationfrmId", _LocationfrmId);
            return objDBBridge.ExecuteNonQuery(_spName, param);
        }

        public DataSet SelectAll()
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@Mode", "View");
            return objDBBridge.ExecuteDataset(_spName, param);
        }

        public void SelectById()
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@Mode", "ViewByID");
            param[1] = new SqlParameter("@LocationfrmId", _LocationfrmId);
            //DataTable dtDepartment = new DataTable();
            DataTable dtLocation = new DataTable();
            dtLocation = objDBBridge.ExecuteDataset(_spName, param).Tables[0];
            if (dtLocation.Rows.Count != 0)
            {
                DataRow drLocation;
                drLocation = dtLocation.Rows[0];
                _LocationfrmName = drLocation["LocationfrmName"].ToString();
            }
        }
        #endregion
    }
}
