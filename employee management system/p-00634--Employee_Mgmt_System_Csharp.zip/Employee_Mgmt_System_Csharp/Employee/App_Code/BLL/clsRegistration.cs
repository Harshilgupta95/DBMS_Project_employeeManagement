﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Employee.DAL;
using System.Data.SqlClient;

namespace Employee.BLL
{
    public class clsRegistration
    {
        public clsRegistration()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        #region Variables
        DBBridge objDBBridge = new DBBridge();
        protected int _RegId;
        protected string _EmployeeName = String.Empty;
        protected string _DriverName = String.Empty;
        protected string _Locationfrm = String.Empty;
        protected string _Locationto = String.Empty;
        protected string _StartingKm = String.Empty;
        protected string _ClosingKm = String.Empty;
        protected string _Startingtime = String.Empty;
        protected string _Closingtime = String.Empty;
        protected string _Triptype = String.Empty;
        protected DateTime _DOT;
        protected string _CompanyName = String.Empty;
        protected string _Advance = String.Empty;
        protected string _Diesel = String.Empty;
        protected DateTime _DateofEntry;
        const string _spName = "sp_tblRegDetails";
        #endregion

        #region Class Property
        public int RegId
        {
            get { return _RegId; }
            set { _RegId = value; }
        }

        public string EmployeeName
        {
            get { return _EmployeeName; }
            set { _EmployeeName = value; }
        }
        public string DriverName
        {
            get { return _DriverName; }
            set { _DriverName = value; }
        }
        public string Locationfrm
        {
            get { return _Locationfrm; }
            set { _Locationfrm = value; }
        }
        public string Locationto
        {
            get { return _Locationto; }
            set { _Locationto = value; }
        }
        public string StartingKm
        {
            get { return _StartingKm; }
            set { _StartingKm = value; }
        }
        public string ClosingKm
        {
            get { return _ClosingKm; }
            set { _ClosingKm = value; }
        }
        public string Startingtime
        {
            get { return _Startingtime; }
            set { _Startingtime = value; }
        }
        public string Closingtime
        {
            get { return _Closingtime; }
            set { _Closingtime = value; }
        }
        public string Triptype
        {
            get { return _Triptype; }
            set { _Triptype = value; }
        }
        public DateTime DOT 
        {
            get { return _DOT; }
            set { _DOT = value; }
        }
        public string CompanyName
        {
            get { return _CompanyName; }
            set { _CompanyName = value; }
        }
        public string Advance
        {
            get { return _Advance; }
            set { _Advance = value; }
        }
        public string Diesel
        {
            get { return _Diesel; }
            set { _Diesel = value; }
        }
        public DateTime DateofEntry
        {
            get { return _DateofEntry; }
            set { _DateofEntry = value; }
        }
        #endregion

        #region Public Methods

        public int Insert()
        {
            SqlParameter[] param = new SqlParameter[15];
            param[0] = new SqlParameter("@Mode", "Insert");
            param[1] = new SqlParameter("@EmployeeName", _EmployeeName);
            param[2] = new SqlParameter("@DriverName", _DriverName);
            param[3] = new SqlParameter("@DOT", _DOT);
            param[4] = new SqlParameter("@ClientName", _CompanyName);
            param[5] = new SqlParameter("@Locationfrm", _Locationfrm);
            param[6] = new SqlParameter("@LocationTo", _Locationto);
            param[7] = new SqlParameter("@StartingKm", _StartingKm);
            param[8] = new SqlParameter("@ClosingKm", _ClosingKm);
            param[9] = new SqlParameter("@TripType", _Triptype);
            param[10] = new SqlParameter("@Advance", _Advance);
            param[11] = new SqlParameter("@Diesel", _Diesel);
            param[12] = new SqlParameter("@DateofEntry", _DateofEntry);
            param[13] = new SqlParameter("@StartingTime", _Startingtime);
            param[14] = new SqlParameter("@ClosingTime", _Closingtime);
            return objDBBridge.ExecuteNonQuery(_spName, param);
        }

        public int Update()
        {
            SqlParameter[] param = new SqlParameter[15];
            param[0] = new SqlParameter("@Mode", "Insert");
            param[1] = new SqlParameter("@EmployeeName", _EmployeeName);
            param[2] = new SqlParameter("@DriverName", _DriverName);
            param[3] = new SqlParameter("@DOT", _DOT);
            param[4] = new SqlParameter("@ClientName", _CompanyName);
            param[5] = new SqlParameter("@Locationfrm", _Locationfrm);
            param[6] = new SqlParameter("@LocationTo", _Locationto);
            param[7] = new SqlParameter("@StartingKm", _StartingKm);
            param[8] = new SqlParameter("@ClosingKm", _ClosingKm);
            param[9] = new SqlParameter("@TripType", _Triptype);
            param[10] = new SqlParameter("@Advance", _Advance);
            param[11] = new SqlParameter("@Diesel", _Diesel);
            param[12] = new SqlParameter("@DateofEntry", _DateofEntry);
            param[13] = new SqlParameter("@StartingTime", _Startingtime);
            param[14] = new SqlParameter("@ClosingTime", _Closingtime);
            return objDBBridge.ExecuteNonQuery(_spName, param);
        }

        public int Delete()
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@Mode", "Delete");
            param[1] = new SqlParameter("@RegId", _RegId);
            return objDBBridge.ExecuteNonQuery(_spName, param);
        }

        public DataSet Select()
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@Mode", "ViewActive");
            return objDBBridge.ExecuteDataset(_spName, param);
        }

        /* public DataSet SelectByExperience()
        {
            SqlParameter[] param = new SqlParameter[2];
            if (_Years == -1)
            {
                param[0] = new SqlParameter("@Mode", "ViewService");
            }
            else
            {
                param[0] = new SqlParameter("@Mode", "FilterService");
            }
            param[1] = new SqlParameter("@Years", _Years);
            return objDBBridge.ExecuteDataset(_spName, param);
        }*/

        /* public DataSet ViewYears()
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@Mode", "ViewYears");
            return objDBBridge.ExecuteDataset(_spName, param);
        } */


        /* public DataSet SelectInActive()
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@Mode", "ViewInActive");
            return objDBBridge.ExecuteDataset(_spName, param);
        } */

        public DataSet SelectAll()
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@Mode", "View");
            return objDBBridge.ExecuteDataset(_spName, param);
        }

        /* public DataSet Birthday()
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@Mode", "Birthday");
            return objDBBridge.ExecuteDataset(_spName, param);
        }*/

        public void SelectById()
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@Mode", "ViewByID");
            param[1] = new SqlParameter("@RegId", _RegId);
            DataTable dtRegistration = new DataTable();
            dtRegistration = objDBBridge.ExecuteDataset(_spName, param).Tables[0];
            if (dtRegistration.Rows.Count != 0)
            {
                DataRow drRegistration;
                drRegistration = dtRegistration.Rows[0];
                _EmployeeName = drRegistration["EmployeeName"].ToString();
                _DriverName = drRegistration["DriverName"].ToString();
                _Locationfrm = drRegistration["Locationfrm"].ToString();
                _Locationto = drRegistration["Locationto"].ToString();
                _StartingKm = drRegistration["StartingKm"].ToString();
                _ClosingKm = drRegistration["ClosingKm"].ToString();
                _Startingtime = drRegistration["StartingTime"].ToString();
                _Closingtime = drRegistration["ClosingTime"].ToString();
                _Triptype = drRegistration["TripType"].ToString();
                _DOT = Convert.ToDateTime(drRegistration["DOT"]);
                _CompanyName = drRegistration["ClientName"].ToString();
                _Advance = drRegistration["Advance"].ToString();
                _Diesel = drRegistration["Diesel"].ToString();
                _DateofEntry = Convert.ToDateTime(drRegistration["DateofEntry"]);
             }
        }

     /*   public string EmployeeCount()
        {
            string cntEmp = "0";
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@Mode", "EmpCount");
            DataTable dtEmployee = new DataTable();
            dtEmployee = objDBBridge.ExecuteDataset(_spName, param).Tables[0];
            if (dtEmployee.Rows.Count != 0)
            {
                DataRow drRegistration;
                drRegistration = dtEmployee.Rows[0];
                cntEmp = drRegistration["EmpCount"].ToString();
            }
            return cntEmp;
        } */
        #endregion
    }
}