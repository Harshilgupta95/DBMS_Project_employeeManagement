Employee Management System

Steps to Setup the Project

1) Create an Database with an any name.

2) Execute the Tables.sql and StoredProcedures.sql script on the new database.

3) Open the project as Website in VS 2005. (File->Open->Website)

4) Update the Connection String on Web.Config file with your DB Server Name, Database name, Username and Password.

5) Run the project with Default.aspx as start page. 


For any questions or queries feel free to email me at shyamsrinivas@gmail.com