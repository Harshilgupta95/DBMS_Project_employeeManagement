CREATE TABLE [tblLogin](
	[LoginId] [int] IDENTITY(1,1) NOT NULL,
	[LoginName] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Email] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Username] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Password] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Rights] [int] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL
) ON [PRIMARY]

GO


INSERT INTO [tblLogin]
           ([LoginName]
           ,[Email]
           ,[Username]
           ,[Password]
           ,[Rights]
           ,[ModifiedDate])
     VALUES
           ('Administrator'
           ,'admin@admin.com'
           ,'admin'
           ,'admin'
           ,1
           ,getdate())


-- CREATE TABLE [tblDepartment](
--	[DepartmentId] [int] IDENTITY(1,1) NOT NULL,
--	[DepartmentName] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
--) ON [PRIMARY]

--GO


--INSERT INTO [tblDepartment] ([DepartmentName]) VALUES ('Management')
--INSERT INTO [tblDepartment] ([DepartmentName]) VALUES ('HR')
--INSERT INTO [tblDepartment] ([DepartmentName]) VALUES ('Engineering')
--INSERT INTO [tblDepartment] ([DepartmentName]) VALUES ('Accounts')


CREATE TABLE [tblDriver](
	[DriverId] [int] IDENTITY(1,1) NOT NULL,
	[DriverName] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]

GO


INSERT INTO [tblDriver] ([DriverName]) VALUES ('Imran')
INSERT INTO [tblDriver] ([DriverName]) VALUES ('Sanjay')


CREATE TABLE [tblLocationfrom](
	[LocationfrmId] [int] IDENTITY(1,1) NOT NULL,
	[LocationfrmName] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]

GO


INSERT INTO [tblLocationfrom] ([LocationfrmName]) VALUES ('Mumbai')
INSERT INTO [tblLocationfrom] ([LocationfrmName]) VALUES ('Pune')


CREATE TABLE [tblLocationto](
	[LocationtoId] [int] IDENTITY(1,1) NOT NULL,
	[LocationtoName] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]

GO


INSERT INTO [tblLocationto] ([LocationtoName]) VALUES ('Mumbai')
INSERT INTO [tblLocationto] ([LocationtoName]) VALUES ('Pune')



CREATE TABLE [tblEmployee](
	[EmployeeId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DOB] [datetime] NOT NULL,
	[Degree] [varchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Address] [varchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[City] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[State] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Zip] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Phone] [varchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Mobile] [varchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Email] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Designation] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DepartmentId] [int] NOT NULL,
	[DOJ] [datetime] NOT NULL,
	[DOC] [datetime] NOT NULL,
	[Bio] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Photo] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Status] [int] NOT NULL,
 CONSTRAINT [PK_tblEmployee] PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


CREATE TABLE [tblRegDetails](
	[RegId] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeName] [varchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DriverName] [varchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DOT] [datetime] NOT NULL,
	[Locationfrm] [varchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[LocationTo] [varchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[StartingKm] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ClosingKm] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ClientName] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Advance] [varchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Diesel] [varchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DateofEntry] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[StartingTime] [varchar](100) NOT NULL,
	[ClosingTime] [varchar](100)[datetime] NOT NULL,
	
 CONSTRAINT [PK_tblRegDetails] PRIMARY KEY CLUSTERED 
(
	[RegId] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


CREATE TABLE [tblClientName](
	[ClientId] [int] IDENTITY(1,1) NOT NULL,
	[ClientName] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


