CREATE TABLE [tblLogin](
	[LoginId] [int] IDENTITY(1,1) NOT NULL,
	[LoginName] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Email] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Username] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Password] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Rights] [int] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL
) ON [PRIMARY]

GO


INSERT INTO [tblLogin]
           ([LoginName]
           ,[Email]
           ,[Username]
           ,[Password]
           ,[Rights]
           ,[ModifiedDate])
     VALUES
           ('Administrator'
           ,'admin@admin.com'
           ,'admin'
           ,'admin'
           ,1
           ,getdate())


-- CREATE TABLE [tblDepartment](
--	[DepartmentId] [int] IDENTITY(1,1) NOT NULL,
--	[DepartmentName] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
--) ON [PRIMARY]

--GO


--INSERT INTO [tblDepartment] ([DepartmentName]) VALUES ('Management')
--INSERT INTO [tblDepartment] ([DepartmentName]) VALUES ('HR')
--INSERT INTO [tblDepartment] ([DepartmentName]) VALUES ('Engineering')
--INSERT INTO [tblDepartment] ([DepartmentName]) VALUES ('Accounts')


CREATE TABLE [tblDriver](
	[DriverId] [int] IDENTITY(1,1) NOT NULL,
	[DriverName] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]

GO


INSERT INTO [tblDriver] ([DriverName]) VALUES ('Imran')
INSERT INTO [tblDriver] ([DriverName]) VALUES ('Sanjay')


CREATE TABLE [tblLocationfrom](
	[LocationfrmId] [int] IDENTITY(1,1) NOT NULL,
	[LocationfrmName] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]

GO


INSERT INTO [tblLocationfrom] ([LocationfrmName]) VALUES ('Mumbai')
INSERT INTO [tblLocationfrom] ([LocationfrmName]) VALUES ('Pune')


CREATE TABLE [tblLocationto](
	[LocationtoId] [int] IDENTITY(1,1) NOT NULL,
	[LocationtoName] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]

GO


INSERT INTO [tblLocationto] ([LocationtoName]) VALUES ('Mumbai')
INSERT INTO [tblLocationto] ([LocationtoName]) VALUES ('Pune')



CREATE TABLE [tblEmployee](
	[EmployeeId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DOB] [datetime] NOT NULL,
	[Degree] [varchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Address] [varchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[City] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[State] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Zip] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Phone] [varchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Mobile] [varchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Email] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Designation] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DepartmentId] [int] NOT NULL,
	[DOJ] [datetime] NOT NULL,
	[DOC] [datetime] NOT NULL,
	[Bio] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Photo] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Status] [int] NOT NULL,
 CONSTRAINT [PK_tblEmployee] PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


CREATE TABLE [tblRegDetails](
	[RegId] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeName] [varchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DriverName] [varchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DOT] [datetime] NOT NULL,
	[Locationfrm] [varchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[LocationTo] [varchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[StartingKm] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ClosingKm] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[TripType] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ClientName] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Advance] [varchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Diesel] [varchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[DateofEntry] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[StartingTime] [varchar](100) NOT NULL,
	[ClosingTime] [varchar](100) NOT NULL,
CONSTRAINT [PK_tblRegDetails] PRIMARY KEY CLUSTERED 
(
	[RegId] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
)

GO


CREATE TABLE [tblClientName](
	[ClientId] [int] IDENTITY(1,1) NOT NULL,
	[ClientName] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


Select * from tblClientName
/**********************************************************************************************/

CREATE PROCEDURE [sp_tblLogin]
@LoginId int=null,
@LoginName varchar(100)=null,
@Email varchar(100)=null,
@Username varchar(20)=null,
@Password varchar(20)=null,
@Rights int=null,
@Mode varchar(25)
AS

IF (@Mode='Insert') 
IF NOT EXISTS (SELECT * FROM tblLogin WHERE Username=@Username)
BEGIN
	INSERT INTO tblLogin(LoginName,Email,Username,Password,Rights,ModifiedDate) VALUES(@LoginName,@Email,@Username,@Password,@Rights,getdate())
END

IF (@Mode='View') 
BEGIN
	SELECT * FROM tblLogin
END

IF (@Mode='ViewByID') 
BEGIN
	SELECT * FROM tblLogin WHERE LoginId = @LoginId
END

IF (@Mode='ChkLogin') 
BEGIN
	SELECT * FROM tblLogin WHERE Username = @Username and Password = @Password
END

IF (@Mode='Update') 
BEGIN
	UPDATE [tblLogin]
	SET [LoginName] = @LoginName
      ,[Email] = @Email
      ,[Username] = @Username
      ,[Password] = @Password
	  ,[Rights] = @Rights
      ,[ModifiedDate] = getdate()
	WHERE LoginId = @LoginId
END

IF (@Mode='Delete') 
BEGIN
	DELETE FROM [tblLogin] WHERE LoginId = @LoginId
END
GO

/**********************************************************************************************/


CREATE PROCEDURE [dbo].[sp_tblClientname]
@ClientId int=null,
@ClientName varchar(100)=null,
@Mode varchar(25)
AS

IF (@Mode='Insert') 
BEGIN
	INSERT INTO tblClientName(ClientName) VALUES(@ClientName)
END

IF (@Mode='View') 
BEGIN
	SELECT * FROM tblClientname
END

IF (@Mode='ViewByID') 
BEGIN
	SELECT * FROM tblClientname WHERE ClientId = @ClientId
END

IF (@Mode='Update') 
BEGIN
	UPDATE tblClientname
	SET ClientName = @ClientName
	WHERE ClientId = @ClientId
END

IF (@Mode='Delete') 
BEGIN
	DELETE FROM tblClientname WHERE ClientId = @ClientId
END

GO

Drop procedure [dbo].[sp_tblClientname]
/**********************************************************************************************/

CREATE PROCEDURE [dbo].[sp_tblDriver]
@DriverId int=null,
@DriverName varchar(100)=null,
@Mode varchar(25)
AS

IF (@Mode='Insert') 
IF NOT EXISTS (SELECT * FROM tblDriver WHERE DriverName=@DriverName)
BEGIN
	INSERT INTO tblDriver(DriverName) VALUES(@DriverName)
END

IF (@Mode='View') 
BEGIN
	SELECT * FROM tblDriver
END

IF (@Mode='ViewByID') 
BEGIN
	SELECT * FROM tblDriver WHERE DriverId = @DriverId
END

IF (@Mode='Update') 
BEGIN
	UPDATE tblDriver
	SET Drivername = @Drivername
	WHERE DriverId = @DriverId
END

IF (@Mode='Delete') 
BEGIN
	DELETE FROM tblDriver WHERE DriverId = @DriverId
END

/**********************************************************************************************/

CREATE PROCEDURE [dbo].[sp_tblLocation]
@LocationfrmId int=null,
@LocationfrmName varchar(100)=null,
@Mode varchar(25)
AS

IF (@Mode='Insert') 
IF NOT EXISTS (SELECT * FROM tblLocationfrom WHERE LocationfrmName=@LocationfrmName)
BEGIN
	INSERT INTO tblLocationfrom(LocationfrmName) VALUES(@LocationfrmName)
	INSERT INTO tblLocationto(LocationtoName) VALUES(@LocationfrmName)
END

IF (@Mode='View') 
BEGIN
	SELECT * FROM tblLocationfrom
END

IF (@Mode='ViewByID') 
BEGIN
	SELECT * FROM tblLocationfrom WHERE LocationfrmId = @LocationfrmId
END

IF (@Mode='Update') 
BEGIN
	UPDATE tblLocationfrom
	SET LocationfrmName = @LocationfrmName
	WHERE LocationfrmId = @LocationfrmId
END

IF (@Mode='Delete') 
BEGIN
	DELETE FROM tblLocationfrom WHERE LocationfrmId = @LocationfrmId
	DELETE FROM tblLocationto WHERE LocationtoId = @LocationfrmId
END
GO


CREATE PROCEDURE [sp_tblEmployee]
@EmployeeId int=null,
@Name varchar(200)=null,
@DOB datetime=null,
@Degree varchar(200)=null,
@Address varchar(300)=null,
@City varchar(50)=null,
@State varchar(50)=null,
@Zip varchar(50)=null,
@Phone varchar(15)=null,
@Mobile varchar(15)=null,
@Email varchar(100)=null,
@Designation varchar(100)=null,
@DepartmentId int=null,
@DOJ datetime=null,
@DOC datetime=null,
@Bio text=null,
@Photo varchar(100)=null,
@Status int=null,
@Years int=null,
@Mode varchar(25)
AS

IF (@Mode='Insert') 
IF NOT EXISTS (SELECT * FROM [tblEmployee] WHERE [Name]=@Name and DOB=@DOB)
BEGIN
	INSERT INTO [tblEmployee]
           ([Name]
           ,[DOB]
		   ,[Degree]
           ,[Address]
           ,[City]
           ,[State]
           ,[Zip]
           ,[Phone]
           ,[Mobile]
           ,[Email]
           ,[Designation]
           ,[DepartmentId]
           ,[DOJ]
           ,[DOC]
           ,[Bio]
           ,[Photo]
           ,[Status])
     VALUES
           (@Name
           ,@DOB
		   ,@Degree
           ,@Address
           ,@City
           ,@State
           ,@Zip
           ,@Phone
           ,@Mobile
           ,@Email
           ,@Designation
           ,@DepartmentId
           ,@DOJ
           ,@DOC
           ,@Bio
           ,@Photo
           ,@Status)
END

IF (@Mode='View') 
BEGIN
	SELECT * FROM [tblEmployee]
END

IF (@Mode='ViewActive') 
BEGIN
	SELECT * FROM [tblEmployee] WHERE Status = 1 ORDER BY DepartmentId, DOJ
END

IF (@Mode='ViewInActive') 
BEGIN
	SELECT * FROM [tblEmployee] WHERE Status = 0
END

IF (@Mode='ViewByID') 
BEGIN
	SELECT * FROM [tblEmployee] WHERE EmployeeId = @EmployeeId
END

IF (@Mode='ViewService') 
BEGIN
	SELECT *,DATEDIFF(year, DOJ, getdate()) as Experience FROM [tblEmployee] WHERE Status = 1 ORDER BY DOJ
END

IF (@Mode='FilterService') 
BEGIN
	SELECT *,DATEDIFF(year, DOJ, getdate()) as Experience FROM [tblEmployee] WHERE Status = 1 and DATEDIFF(Year, DOJ, getdate())=@Years ORDER BY DOJ
END

IF (@Mode='ViewYears') 
BEGIN
	SELECT distinct DATEDIFF(Year, DOJ, getdate()) as EmpExp FROM [tblEmployee] WHERE Status = 1
END

IF (@Mode='Update') 
BEGIN
	UPDATE [tblEmployee]
	SET [Name] = @Name
      ,[DOB] = @DOB
	  ,[Degree] = @Degree
      ,[Address] = @Address
      ,[City] = @City
      ,[State] = @State
      ,[Zip] = @Zip
      ,[Phone] = @Phone
      ,[Mobile] = @Mobile
      ,[Email] = @Email
      ,[Designation] = @Designation
      ,[DepartmentId] = @DepartmentId
      ,[DOJ] = @DOJ
      ,[DOC] = @DOC
      ,[Bio] = @Bio
      ,[Photo] = @Photo
      ,[Status] = @Status
	WHERE EmployeeId = @EmployeeId
END

IF (@Mode='Delete') 
BEGIN
	DELETE FROM [tblEmployee] WHERE EmployeeId = @EmployeeId
END

IF (@Mode='Birthday') 
BEGIN
	SELECT * FROM tblEmployee WHERE DATEPART(MONTH, [DOB]) = DATEPART(MONTH, getdate()) and Status = 1 ORDER BY DATEPART(DAY, [DOB]) 
END

IF (@Mode='EmpCount') 
BEGIN
	SELECT count(EmployeeId) as EmpCount FROM tblEmployee WHERE Status = 1
END

GO

/**********************************************************************************************/
DROP TABLE tblRegDetails
DROP PROCEDURE [sp_tblRegDetails]
CREATE PROCEDURE [sp_tblRegDetails]
@RegId int=null,
@EmployeeName varchar(200)=null,
@DriverName varchar(200)=null,
@DOT datetime=null,
@ClientName varchar(250)=null,
@Locationfrm varchar(250)=null,
@LocationTo varchar(300)=null,
@StartingKm varchar(50)=null,
@ClosingKm varchar(50)=null,
@TripType varchar(50)=null,
@Advance varchar(15)=null,
@Diesel varchar(15)=null,
@DateofEntry varchar(100)=null,
@StartingTime varchar(100)=null,
@ClosingTime varchar(100)=null,
@Mode varchar(25)
AS

IF (@Mode='Insert') 
BEGIN
	INSERT INTO [tblRegDetails]
           ([EmployeeName]
           ,[DriverName]
		   ,[DOT]
		   ,[ClientName]	
           ,[Locationfrm]
           ,[LocationTo]
           ,[StartingKm]
           ,[ClosingKm]
           ,[TripType]
		   ,[Advance]
           ,[Diesel]
           ,[DateofEntry]
           ,[StartingTime]
           ,[ClosingTime])
     VALUES
           (@EmployeeName
           ,@DriverName
		   ,@DOT
		   ,@ClientName	
           ,@Locationfrm
           ,@LocationTo
           ,@StartingKm
           ,@ClosingKm
           ,@TripType
		   ,@Advance
           ,@Diesel
           ,@DateofEntry
           ,@StartingTime
           ,@ClosingTime)
END

IF (@Mode='View') 
BEGIN
	SELECT A.RegId,E.Name,A.DriverName,C.ClientName,B.LocationfrmName,F.LocationtoName,D.Triptype,A.DOT FROM tblRegDetails A,tblLocationfrom B,tblClientName C,
		tblTriptype D,tblEmployee E,tblLocationto F
	Where 
			A.Locationfrm = B.LocationfrmId 
	AND 
			A.ClientName=C.ClientId
	AND
			A.Triptype= D.TripId
	AND 
			A.EmployeeName = E.EmployeeId
	AND 
			A.Locationto = F.LocationtoId
END


IF (@Mode='ViewByID') 
BEGIN
	SELECT * FROM [tblRegDetails] WHERE RegId = @RegId
END


IF (@Mode='Update') 
BEGIN
	UPDATE [tblRegDetails]
	SET [EmployeeName]=@EmployeeName
           ,[DriverName]=@DriverName
		   ,[DOT]=@DOT
		   ,[ClientName]=@ClientName	
           ,[Locationfrm]=@Locationfrm
           ,[LocationTo]=@LocationTo
           ,[StartingKm]=@StartingKm
           ,[ClosingKm]=@ClosingKm
		   ,[TripType]=@TripType	
           ,[Advance]=@Advance
           ,[Diesel]=@Diesel
           ,[DateofEntry]=@DateofEntry
           ,[StartingTime]=@StartingTime
           ,[ClosingTime]=@ClosingTime
	WHERE RegId = @RegId
END

IF (@Mode='Delete') 
BEGIN
	DELETE FROM [tblRegDetails] WHERE RegId = @RegId
END


GO

Select * from tblRegDetails
/**********************************************************************************************/













CREATE PROCEDURE [sp_tblRegDetails]
@TrainingId int=null,
@StartDate datetime=null,
@EndDate datetime=null,
@TrainingDetails text=null,
@Effectiveness text=null,
@JobType int=null,
@EmployeeId int=null,
@Mode varchar(25)
AS

IF (@Mode='Insert') 
BEGIN
	INSERT INTO [tblTrainings]
           ([StartDate]
           ,[EndDate]
           ,[TrainingDetails]
           ,[Effectiveness]
           ,[JobType]
		   ,[EmployeeId])
     VALUES
           (@StartDate
           ,@EndDate
           ,@TrainingDetails
           ,@Effectiveness
           ,@JobType
		   ,@EmployeeId)
END

IF (@Mode='ViewByEmployee') 
BEGIN
	SELECT * FROM [tblTrainings] WHERE EmployeeId = @EmployeeId AND JobType = @JobType ORDER BY StartDate
END

IF (@Mode='ViewByID') 
BEGIN
	SELECT * FROM [tblTrainings] WHERE TrainingId = @TrainingId
END

IF (@Mode='Update') 
BEGIN
	UPDATE [tblTrainings]
	SET [StartDate] = @StartDate,
		[EndDate] = @EndDate,
		[TrainingDetails] = @TrainingDetails,
		[Effectiveness] = @Effectiveness,
		[JobType] = @JobType
	WHERE TrainingId = @TrainingId
END

IF (@Mode='Delete') 
BEGIN
	DELETE FROM [tblTrainings] WHERE TrainingId = @TrainingId
END

GO


SELECT A.RegId,E.Name,C.ClientName,B.LocationfrmName,F.LocationtoName,D.Triptype,A.DOT FROM tblRegDetails A,tblLocationfrom B,tblClientName C,
		tblTriptype D,tblEmployee E,tblLocationto F
Where 
		A.Locationfrm = B.LocationfrmId 
AND 
		A.ClientName=C.ClientId
AND
		A.Triptype= D.TripId
AND 
		A.EmployeeName = E.EmployeeId
AND 
		A.Locationto = F.LocationtoId
			
		


SELECT * FROM tblRegDetails
SELECT * FROM tblLocationfrom
SELECT * FROM tblClientName
SELECT * FROM tblTripType
SELECT * FROM tblEmployee 