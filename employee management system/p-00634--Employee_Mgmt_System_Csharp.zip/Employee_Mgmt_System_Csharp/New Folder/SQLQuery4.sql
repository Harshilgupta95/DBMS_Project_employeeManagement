Select * from tblClientName

Select * from tblLocationfrm
Select * from tblLocationto